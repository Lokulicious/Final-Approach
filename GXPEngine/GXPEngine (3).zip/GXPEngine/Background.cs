﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GXPEngine;

class Background : Sprite
{
    public Background() : base("background_concept.png")
    {

    }

}
